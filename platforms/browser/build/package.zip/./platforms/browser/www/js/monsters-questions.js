/**
 *  MQ: Monsters Questions
 */
var MQ = {

    /**
     * Properties
     */

    monsters: [],

    monstersPresented : [
        '5y_re_mustache', '1y_ro_wig', '11r_re_beard', '9r_ro_horns', '8r_ro_antenna', '2y_ro_horn', '4y_re_elvis', '6y_re_wings', '10r_re_viking', '3y_ro_hair', '7r_ro_crown', '12r_re_pipe'
    ],

    monstersDistractors : [
       
    ],
    
    
    /**
     * Cordova: initialize()
     */
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },


    /**
     * Cordova: onDeviceReady()
     */
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
    },

    
    /**
     * Cordova: receivedEvent()
     */
    receivedEvent: function(id) {

        switch (id) {
            case 'deviceready':
                this.Setup();
                break;
        }

        console.log('Received Event: ' + id);
    },


    /**
     * Setup()
     */
    Setup: function() {

        
    },


    /**
     * Start()
     */
    Start: function() {
        console.log('MQ start');

        app.Goto('rt-monsters-questions');
        
        /* Shuffle objects and populate objects property
        OQ.objectsPresented = app.ArrayShuffle(OQ.objectsPresented);
        OQ.objectsDistractors = app.ArrayShuffle(OQ.objectsDistractors);
        OQ.objects = OQ.objectsPresented.concat(OQ.objectsDistractors);*/

    }


};

MQ.initialize();