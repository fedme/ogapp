/**
 *  OQ: Object Questions
 */
var OQ = {

    /**
     * Properties
     */

    objects: [],
    monstersObjects: {},
    currentQuestion: 0,
    buttons: [],
    userAnswers: [],

    objectsPresented : [
        "bol", "chaussure", "ciseaux", "cle", "fourchette", "gateau", "lunettes", "marteau", "montre", "pantalon", "pomme", "vis"
    ],

    objectsDistractors : [
        "chapeau", "cuillere", "livre", "oeuf", "scie", "serrure"
    ],
    
    
    /**
     * Cordova: initialize()
     */
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },


    /**
     * Cordova: onDeviceReady()
     */
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
    },

    
    /**
     * Cordova: receivedEvent()
     */
    receivedEvent: function(id) {

        switch (id) {
            case 'deviceready':
                OQ.Setup();
                OQ.SetHandlers();
                break;
        }

        console.log('Received Event: ' + id);
    },


    /**
     * Setup()
     */
    Setup: function() {

        
    },

    /**
     * SetHandlers()
     */
    SetHandlers: function() {

        OQ.buttons[0] = document.getElementById('btn-show-objects-placement');
        OQ.buttons[0].addEventListener('click', OQ.ObjectPlacement);

        OQ.buttons[1] = document.getElementById('btn-go-objects-questions');
        OQ.buttons[1].addEventListener('click', OQ.ObjectQuestionsSetupDialog);

        OQ.buttons[2] = document.getElementById('btn-objects-question-yes');
        OQ.buttons[2].addEventListener('click', OQ.AnswerYes);

        OQ.buttons[3] = document.getElementById('btn-objects-question-no');
        OQ.buttons[3].addEventListener('click', OQ.AnswerNo);

    },


    /**
     * Start()
     */
    Start: function() {
        console.log('OQ start');

        app.Goto('rt-objects-placement');
        
        // Shuffle objects and populate objects property
        OQ.objectsPresented = app.ArrayShuffle(OQ.objectsPresented);

        for (var i=0; i < MQ.monstersPresented.length; i++) {
            var monster = MQ.monstersPresented[i];
            OQ.monstersObjects[monster] = OQ.objectsPresented[i];
        }

        console.log(OQ.monstersObjects);

    },


    /**
     * ObjectPlacement()
     */
    ObjectPlacement: function() {

        var list = document.querySelectorAll('#rt-objects-placement ul')[0];
        list.innerHTML = '';
        document.body.style.overflowY = 'scroll';

        for (var i=0; i < MQ.monstersPresented.length; i++) {
            var monster = MQ.monstersPresented[i];
            var object = OQ.monstersObjects[monster];
            list.innerHTML = list.innerHTML + '<li><img src="img/monsters/' + monster +'.png"><img src="img/objects/' + object +'.jpg"></li>';
        }

        document.getElementById('btn-go-objects-questions').style.display = "inline-block";

    },


    /**
     * ObjectQuestionsSetupDialog()
     */
    ObjectQuestionsSetupDialog: function() {
      navigator.notification.confirm(
            'Have you placed the objects as showed on the screen?', // message
            OQ.ObjectQuestionsSetup,            // callback to invoke with index of button pressed
            'Are you sure?',           // title
            ['Yes','No']     // buttonLabels
        );
    },


    /**
     * ObjectQuestionsSetup()
     */
    ObjectQuestionsSetup: function(buttonIndex) {
        if (buttonIndex !== 1) return;

        // concat and shuffle presented and distractor objects
        OQ.objects = OQ.objectsPresented.concat(OQ.objectsDistractors);
        OQ.objects = app.ArrayShuffle(OQ.objects);

        OQ.AskQuestion();
        app.Goto('rt-objects-questions');
    },


    /**
     * AskQuestion()
     */
    AskQuestion: function() {

        if (OQ.currentQuestion >= 17) return OQ.End();
        var img = document.querySelectorAll('#rt-objects-questions img')[0];
        var object = OQ.objects[OQ.currentQuestion];
        img.setAttribute('src', 'img/objects/' + object + '.jpg');
    },


    /**
     * AnswerYes()
     */
    AnswerYes: function() {
        OQ.Answer(true);
    },


    /**
     * AnswerNo()
     */
    AnswerNo: function() {
        OQ.Answer(false);
    },


    /**
     * Answer()
     */
    Answer: function(answer) {
        var object = OQ.objects[OQ.currentQuestion];
        OQ.userAnswers.push({
            'object': object,
            'answer': answer
        });

        OQ.currentQuestion++;
        OQ.AskQuestion();
    },


     /**
     * End()
     */
    End: function() {
        //End
    }


};

OQ.initialize();