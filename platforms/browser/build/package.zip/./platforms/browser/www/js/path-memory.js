/**
 * PathMemory Component
 */
var PathMemory = {

    /**
     * Properties
     */
    buttons : [],
    rememberedPath : null,


    /**
     * Cordova: Initialize()
     */
    Initialize: function() {
        document.addEventListener('deviceready', PathMemory.onDeviceReady.bind(PathMemory), false);
    },


    /**
     * Cordova: onDeviceReady()
     */
    onDeviceReady: function() {
        PathMemory.ReceivedEvent('deviceready');
    },


    /**
     * Cordova: ReceivedEvent()
     */
    ReceivedEvent: function(id) {
        switch (id) {
            case 'deviceready':
                PathMemory.Setup();
                PathMemory.SetHandlers();
                break;
        }
    },


    /**
     * Setup()
     */
    Setup: function() {

    },


    /**
     * SetHandlers()
     */
    SetHandlers: function() {

        
        PathMemory.buttons[0] = document.getElementById('btn-save-path-memory');
        PathMemory.buttons[0].addEventListener('click', PathMemory.SaveRememberedPath);
        

        

        /*var cells = document.querySelectorAll('#table1 td');
        for (var i=0; i < cells.length; i++) {
            cells[i].addEventListener('click', MapRoute.CancelSingleCell);
        }*/

    },


    /**
     * Start();
     */
    Start: function() {
        console.log('PathMemory start');

        // resetting MapRoute component
        MapRoute.SetMode('path-memory');
        document.querySelectorAll('#rt-map-route .history')[0].style.display = "none";
        document.getElementById('btn-save-path').style.display = "none";
        document.getElementById('btn-save-path-memory').style.display = "block";
        app.Goto('rt-map-route');

    },


    /**
     * SaveRememberedPath()
     */
    SaveRememberedPath: function() {
        PathMemory.rememberedPath = MapRoute.SavePath();
        console.log(PathMemory.rememberedPath);
    }




};

PathMemory.Initialize();